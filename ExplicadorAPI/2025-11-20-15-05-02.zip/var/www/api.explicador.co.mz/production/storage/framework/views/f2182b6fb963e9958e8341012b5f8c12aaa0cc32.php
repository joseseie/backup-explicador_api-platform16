<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie9" lang="en" > <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en" > <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="JSON API (jsonapi.org) support for Laravel applications.">
    <meta name="author" content="Cloud Creativity Ltd">
    <link rel="shortcut icon" href="img/favicon.ico">
    <title>Home - Laravel Location and Education API</title>
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700|Roboto+Slab:400,700|Inconsolata:400,700' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="<?php echo e(asset('/vendor/api-doc/css/theme.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/vendor/api-doc/css/theme_extra.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/vendor/api-doc/css/highlight.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/vendor/api-doc/css/badge_only.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/vendor/api-doc/css/readthedocs-doc-embed.css')); ?>" type="text/css" />
    
    

    <script>
        // Current page data
        var mkdocs_page_name = "Home";
        var mkdocs_page_input_path = "index.md";
        var mkdocs_page_url = "https://laravel-json-api.readthedocs.io/";
    </script>

    <script src="<?php echo e(asset('/vendor/api-doc/js/jquery-2.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/vendor/api-doc/js/modernizr-2.8.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/vendor/api-doc/js/highlight.pack.js')); ?>"></script>
    
    

</head>

<body class="wy-body-for-nav" role="document">

<div class="wy-grid-for-nav">


    <nav data-toggle="wy-nav-shift" class="wy-nav-side stickynav">
        <div class="wy-side-nav-search">
            <a href="/" class="icon icon-home"> Moz Rest API</a>
            <div role="search">
                <form id ="mkdocs-search-form" class="wy-form" action="https://laravel-json-api.readthedocs.io/en/latest/search.html" method="get">
                    <input type="text" name="q" placeholder="Search docs" />
                </form>
            </div>
        </div>

        <div class="wy-menu wy-menu-vertical" data-spy="affix" role="navigation" aria-label="main navigation">
            <ul class="current">


                <li class="toctree-l1 current">

                    <a class="current" href="/">Home</a>
                    <ul class="subnav">

                        <li class="toctree-l2"><a href="#introduction">Introduction</a></li>

                        <ul>

                            <li><a class="toctree-l3" href="#what-is-json-api">What is JSON API?</a></li>

                            <li><a class="toctree-l3" href="#demo">Demo</a></li>

                            <li><a class="toctree-l3" href="#theory-of-operation">Theory of Operation</a></li>

                        </ul>


                    </ul>
                </li>

                <li class="toctree-l1">

                    <a class="" href="installation/index.html">Installation</a>
                </li>

                <li class="toctree-l1">

                    <a class="" href="upgrade/index.html">Upgrading</a>
                </li>

                <li class="toctree-l1">

                    <span class="caption-text">The Basics</span>
                    <ul class="subnav">
                        <li class="">

                            <a class="" href="basics/api/index.html">APIs</a>
                        </li>
                        <li class="">

                            <a class="" href="basics/routing/index.html">Routing</a>
                        </li>
                        <li class="">

                            <a class="" href="basics/controllers/index.html">Controllers</a>
                        </li>
                        <li class="">

                            <a class="" href="basics/adapters/index.html">Adapters</a>
                        </li>
                        <li class="">

                            <a class="" href="basics/schemas/index.html">Schemas</a>
                        </li>
                        <li class="">

                            <a class="" href="basics/validators/index.html">Validation</a>
                        </li>
                        <li class="">

                            <a class="" href="basics/security/index.html">Security</a>
                        </li>
                        <li class="">

                            <a class="" href="basics/testing/index.html">Testing</a>
                        </li>
                    </ul>
                </li>

                <li class="toctree-l1">

                    <span class="caption-text">Fetching Data</span>
                    <ul class="subnav">
                        <li class="">

                            <a class="" href="fetching/resources/index.html">Fetching Resources</a>
                        </li>
                        <li class="">

                            <a class="" href="fetching/relationships/index.html">Fetching Relationships</a>
                        </li>
                        <li class="">

                            <a class="" href="fetching/inclusion/index.html">Inclusion of Related Resources</a>
                        </li>
                        <li class="">

                            <a class="" href="fetching/sparse-fieldsets/index.html">Sparse Fieldsets</a>
                        </li>
                        <li class="">

                            <a class="" href="fetching/sorting/index.html">Sorting</a>
                        </li>
                        <li class="">

                            <a class="" href="fetching/pagination/index.html">Pagination</a>
                        </li>
                        <li class="">

                            <a class="" href="fetching/filtering/index.html">Filtering</a>
                        </li>
                    </ul>
                </li>

                <li class="toctree-l1">

                    <span class="caption-text">Creating, Updating and Deleting</span>
                    <ul class="subnav">
                        <li class="">

                            <a class="" href="crud/creating/index.html">Creating Resources</a>
                        </li>
                        <li class="">

                            <a class="" href="crud/updating/index.html">Updating Resources</a>
                        </li>
                        <li class="">

                            <a class="" href="crud/relationships/index.html">Updating Relationships</a>
                        </li>
                        <li class="">

                            <a class="" href="crud/deleting/index.html">Deleting Resources</a>
                        </li>
                    </ul>
                </li>

                <li class="toctree-l1">

                    <span class="caption-text">Digging Deeper</span>
                    <ul class="subnav">
                        <li class="">

                            <a class="" href="features/broadcasting/index.html">Broadcasting</a>
                        </li>
                        <li class="">

                            <a class="" href="features/errors/index.html">Errors</a>
                        </li>
                        <li class="">

                            <a class="" href="features/helpers/index.html">Helpers</a>
                        </li>
                        <li class="">

                            <a class="" href="features/http-clients/index.html">HTTP Clients</a>
                        </li>
                        <li class="">

                            <a class="" href="features/packages/index.html">Packages</a>
                        </li>
                        <li class="">

                            <a class="" href="features/responses/index.html">Responses</a>
                        </li>
                        <li class="">

                            <a class="" href="features/views/index.html">Views</a>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>
        &nbsp;
    </nav>

    <section data-toggle="wy-nav-shift" class="wy-nav-content-wrap">


        <nav class="wy-nav-top" role="navigation" aria-label="top navigation">
            <i data-toggle="wy-nav-top" class="fa fa-bars"></i>
            <a href=".html">Laravel JSON API</a>
        </nav>


        <div class="wy-nav-content">
            <div class="rst-content">
                <div role="navigation" aria-label="breadcrumbs navigation">
                    <ul class="wy-breadcrumbs">
                        <li><a href=".html">Docs</a> &raquo;</li>



                        <li>Home</li>
                        <li class="wy-breadcrumbs-aside">

                            <a target="_blank" href="https://github.com/joseseie/explicador-api-v2/blob/master/resources/views/api-doc/index.blade.php"
                               class="icon icon-github"> Edit on GitHub
                            </a>
                            <a href="/admin"
                               class="icon icon-caret-right"> Login
                            </a>

                        </li>
                    </ul>
                    <hr/>
                </div>
                <div role="main">
                    <div class="section">

                        <div style="min-height: 800px">
                            <a href="<?php echo e('/storage/api images/api.png'); ?>" title="Ver a Imagem completa">
                                <img style="height: 100%" src="<?php echo e(asset('storage/api images/api.png')); ?>" alt="API Image">
                            </a>
                        </div>

                        <h1 id="introduction">Introduction</h1>
                        <p>Add <a href="http://jsonapi.org/">jsonapi.org</a> compliant APIs to your Laravel 5 application.
                            Based on the framework agnostic packages <a href="https://github.com/neomerx/json-api">neomerx/json-api</a> and
                            <a href="https://github.com/cloudcreativity/json-api">cloudcreativity/json-api</a>.</p>
                        <h2 id="what-is-json-api">What is JSON API?</h2>
                        <p>From <a href="http://jsonapi.org/">jsonapi.org</a></p>
                        <blockquote>
                            <p>If you've ever argued with your team about the way your JSON responses should be formatted, JSON API is your
                                anti-bikeshedding weapon.</p>
                            <p>By following shared conventions, you can increase productivity, take advantage of generalized tooling, and focus on
                                what matters: your application. Clients built around JSON API are able to take advantage of its features around
                                efficiently caching responses, sometimes eliminating network requests entirely.</p>
                        </blockquote>
                        <p>For full information on the spec, plus examples, see <a href="http://jsonapi.org/">http://jsonapi.org</a>.</p>
                        <h2 id="demo">Demo</h2>
                        <p>We've created a simple <a href="https://github.com/cloudcreativity/demo-laravel-json-api">demo application</a> that is
                            available to download, view the code and play around with as needed.</p>
                        <h2 id="theory-of-operation">Theory of Operation</h2>
                        <p>Your application will have one (or many) APIs that conform to the JSON API spec. You define an API in your via routes,
                            while JSON API settings are configured in a config file for each API. If you have multiple APIs, each has a unique
                            <em>name</em>.</p>
                        <p>A JSON API contains a number of <em>resource types</em> that are available within your API. Each resource type
                            relates directly to a PHP object class. We refer to instances of JSON API resource types as <em>resources</em>, and instances
                            of your PHP classes as <em>records</em>. </p>
                        <p>Each resource type has the following units that serve a particular purpose:</p>
                        <ol>
                            <li><strong>Adapter</strong>: Defines how to query and update records in your application's storage (e.g. database).</li>
                            <li><strong>Schema</strong>: Serializes a record into its JSON API representation.</li>
                            <li><strong>Validators</strong>: Provides validator instances to validate JSON API query parameters and HTTP content body.</li>
                        </ol>
                        <p>Optionally you can also add an <strong>Authorizer</strong> instance to authorize incoming JSON API request, either for multiple
                            resource types or for a specific resource type.</p>
                        <p>Although this may sound like a lot of units, our development approach is to use single-purpose units that
                            are easy to reason about.</p>
                        <h3 id="why-records-not-models">Why <em>Records</em> not <em>Models</em>?</h3>
                        <p>In Laravel the phrase <em>model</em> is potentially confusing with Eloquent models. While some applications might solely
                            encode Eloquent models to JSON API resources, others will use a mixture of Eloquent models and other PHP classes,
                            or might not even be using Eloquent models.</p>
                        <p>So we decided to refer to PHP object instances that are converted to JSON API resources as <em>records</em>.</p>

                    </div>
                </div>
                <footer>

                    <div class="rst-footer-buttons" role="navigation" aria-label="footer navigation">

                        <a href="installation/index.html" class="btn btn-neutral float-right" title="Installation">Next <span class="icon icon-circle-arrow-right"></span></a>


                    </div>


                    <hr/>

                    <div role="contentinfo">
                        <!-- Copyright etc -->

                    </div>

                    Built with <a href="http://www.mkdocs.org/">MkDocs</a> using a <a href="https://github.com/snide/sphinx_rtd_theme">theme</a> provided by <a href="https://readthedocs.org/">Read the Docs</a>.
                </footer>

            </div>
        </div>

    </section>

</div>

<div class="rst-versions" data-toggle="rst-versions" role="note" aria-label="versions">
    <span class="rst-current-version" data-toggle="rst-current-version">
      <span class="fa fa-book"> Read the Docs</span>
      <span class="fa fa-caret-down"></span>
    </span>
    <div class="rst-other-versions">
    </div>
</div>
<script>var base_url = '/';</script>
<script src="<?php echo e(asset('/vendor/api-doc/js/theme.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/api-doc/js/readthedocs-doc-embed.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/api-doc/js/readthedocs-data.js')); ?>"></script>


</body>
</html>

<!--
MkDocs version : 0.17.3
Build Date UTC : 2018-08-31 11:03:00
-->
