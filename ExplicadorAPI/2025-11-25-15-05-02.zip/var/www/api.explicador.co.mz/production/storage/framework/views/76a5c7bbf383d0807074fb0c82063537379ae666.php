<header class="header fixed-top">
    <div class="branding">
        <div class="container-fluid position-relative">
            <nav class="navbar navbar-expand-lg" >
                <div class="site-logo">
                    <a class="navbar-brand" href="/">
                        <img class="logo-icon mr-2" src="https://explicador.co.mz/assets/img/favicon-128x128.png" alt="logo" style="width: 50px;">
                        <span class="logo-text">Explicador<span class="text-alt">API</span></span></a>
                </div>

                <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
                    <span> </span>
                    <span> </span>
                    <span> </span>
                </button>

                <div class="collapse navbar-collapse py-3 py-lg-0" id="navigation">
                    <ul class="social-list list-inline mt-3 mt-lg-0 mb-lg-0 d-none d-xl-flex ml-lg-3 mr-lg-3">
                        <?php echo $__env->make('layouts.inc.social_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </ul><!--//social-list-->
                    <ul class="navbar-nav ml-lg-auto">

                        <li class="nav-item dropdown mr-lg-4">
                            <a class="nav-link" href="docs-page">
                                Documentação
                            </a>
                        </li>
                        <li class="nav-item mr-lg-4">
                            <a class="nav-link" href="#">Outras Soluções</a>
                        </li>
                        <li class="nav-item mr-lg-4">
                            <a class="nav-link" href="contact">Contactos</a>
                        </li>
                        <li class="nav-item mr-lg-4">
                            <a class="nav-link" href="/admin/">Login</a>
                        </li>
                        <li class="nav-item mr-lg-0 mt-3 mt-lg-0">
                            <a class="btn btn-primary text-white" href="/">Criar Conta</a>
                        </li>
                    </ul>
                </div>
            </nav>

        </div><!--//container-->
    </div><!--//branding-->
</header><!--//header-->
