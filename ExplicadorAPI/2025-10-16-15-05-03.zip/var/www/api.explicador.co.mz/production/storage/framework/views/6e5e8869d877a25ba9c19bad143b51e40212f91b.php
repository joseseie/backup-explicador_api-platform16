<head>
    <title>Explicador API</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Explicador Inc">
    <link rel="shortcut icon" href="https://explicador.co.mz/assets/img/favicon-128x128.png">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700&amp;display=swap" rel="stylesheet">

    <!-- FontAwesome JS-->
    <script defer src="<?php echo e(asset('assets/fontawesome/js/all.min.js')); ?>"></script>

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/tiny-slider/tiny-slider.css')); ?>">
    <!-- Theme CSS -->
    <link id="theme-style" rel="stylesheet" href="<?php echo e(asset('assets/css/theme.css')); ?>">

    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/6024f0c79c4f165d47c2361c/1eu84p3ql';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
</head>
