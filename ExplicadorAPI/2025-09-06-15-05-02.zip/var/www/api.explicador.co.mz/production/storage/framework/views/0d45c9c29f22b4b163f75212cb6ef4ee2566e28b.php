<li class="list-inline-item"><a href="https://github.com/joseseie"><i class="fab fa-github fa-fw"></i></a></li>
<li class="list-inline-item"><a href="https://api.whatsapp.com/send?1=pt_BR&phone=258852502501&text=Sauda%C3%A7%C3%B5e%20Equipe%20Explicador,%20Gostaria%20de%20lecionar%20o%20curso%20de:__"><i class="fab fa-wha fa-fw"></i></a></li>
<li class="list-inline-item"><a href="https://www.instagram.com/explicadormz/"><i class="fab fa-instagram fa-fw"></i></a></li>
<li class="list-inline-item"><a href="https://www.facebook.com/explicadormz"><i class="fab fa-facebook fa-fw"></i></a></li>
