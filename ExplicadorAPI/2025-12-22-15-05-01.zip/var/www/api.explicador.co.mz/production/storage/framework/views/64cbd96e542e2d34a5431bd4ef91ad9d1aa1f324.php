<section class="cta-section text-center py-5 theme-bg-dark position-relative">
    <div class="theme-bg-shapes-right"></div>
    <div class="theme-bg-shapes-left"></div>
    <div class="container">
        <h3 class="mb-2 text-white mb-3">Comece imediatamente</h3>
        <div class="section-intro text-white mb-3 single-col-max mx-auto">ExplicadorAPI torna muito fácil colocar seu projeto  online, para que você possa começar a promover ou vender seu produto digital para seu público.</div>
        <div class="pt-3 text-center">
            <a class="btn btn-light" href="https://themes.3rdwavemedia.com/bootstrap-templates/startup/coderpro-bootstrap-4-startup-template-for-software-projects/">Get Started<i class="fas fa-arrow-alt-circle-right ml-2"></i></a>
        </div>
    </div>
</section><!--//cta-section-->
<footer class="footer">
    <div class="container py-5 mb-3">
        <div class="row">
            <div class="footer-col col-6 col-lg-3">
                <h4 class="col-heading">PRODUTOS</h4>
                <ul class="list-unstyled">
                    <li><a href="/">Início</a></li>
                    <li><a href="https://play.google.com/store/apps/details?id=explicador.co.mz">ExplicadorApp (playstore)</a></li>
                    <li><a href="https://app.explicador.co.mz/">ExplicadorApp</a></li>
                    <li><a href="https://account.explicador.co.mz/">eAccountApp</a></li>

                </ul>
            </div><!--//footer-col-->
            <div class="footer-col col-6 col-lg-3">
                <h4 class="col-heading">SERVIÇOS</h4>
                <ul class="list-unstyled">
                    <li><a href="https://app.explicador.co.mz/#/intro">Solicitar Explicador</a></li>
                    <li><a href="https://explicador.co.mz/services">Criação de websites e aplicativos</a></li>
                </ul>
            </div><!--//footer-col-->
            <div class="footer-col col-6 col-lg-3">
                <h4 class="col-heading">EMPRESA</h4>
                <ul class="list-unstyled">
                    <li><a href="#">Documentação</a></li>
                    <li><a href="#">Cominidade</a></li>
                </ul>
            </div><!--//footer-col-->
            <div class="footer-col col-6 col-lg-3">
                <h4 class="col-heading">Explicador API</h4>
                <ul class="list-unstyled">
                    <li><a href="#">Termos de uso</a></li>
                    <li><a href="#">Contactos</a></li>
                </ul>

            </div><!--//footer-col-->
        </div><!--//row-->
    </div><!--//container-->

    <div class="footer-bottom text-center pb-5">
        <small class="copyright">Template Copyright &copy; <a href="https://explicador.co.mz/" target="_blank">© Explicador 2021</a></small>
        <ul class="social-list list-unstyled pt-4 mb-0">
            <?php echo $__env->make('layouts.inc.social_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </ul><!--//social-list-->

    </div>
</footer>
