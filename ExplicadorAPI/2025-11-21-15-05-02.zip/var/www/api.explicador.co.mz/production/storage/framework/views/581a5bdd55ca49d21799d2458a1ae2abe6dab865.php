<!-- Javascript -->
<script src="<?php echo e(asset('assets/plugins/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- Page Specific JS -->
<script src="<?php echo e(asset('assets/js/highlight-custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/typewriterjs/dist/core.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/typewriter-custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/tiny-slider/min/tiny-slider.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/tinyslider-custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/docs.js')); ?>"></script>
