<?php $__env->startSection('main_content'); ?>

<div class="page-header theme-bg-dark py-5 text-center position-relative">
    <div class="theme-bg-shapes-right"></div>
    <div class="theme-bg-shapes-left"></div>
    <div class="container">
        <h1 class="page-heading single-col-max mx-auto">Contate-Nos
        </h1>
        <div class="page-intro single-col-max mx-auto">Entre em contato se você tiver alguma dúvida ou quiser obter um orçamento personalizado
        </div>

    </div>
</div><!--//page-header-->

<div class="page-content py-5">
    <section class="options-section">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-6 mb-5">
                    <div class="media shadow-sm p-4 rounded h-100">
                        <!---
                            /* Uncomment if you want to use a FontAwesome icon instead of an image */
                            <div class="theme-icon-holder mr-4"><i class="far fa-life-ring"></i></div>
                        -->
                        <img class="mr-3" src="<?php echo e(asset('assets/images/streamline-free/customer-service-man.svg')); ?>" alt="">
                        <div class="media-body">
                            <h5 class="mt-0"><a href="#">Suporte ao cliente
                                    <i class="fas fa-long-arrow-alt-right ml-2"></i></a></h5>
                            Se você usa um software de tíquetes de help desk (por exemplo, Zendesk, Groove), pode fornecer mais informações aqui. A ilustração usada aqui é do <a class="theme-link" href="https://api.whatsapp.com/send?1=pt_BR&phone=258852502501&text=Sauda%C3%A7%C3%B5e%20Equipe%20Explicador,%20Gostaria%20de%20lecionar%20o%20curso%20de:__" target="_blank"> pacote de ilustrações gratuitas do Streamline </a>.

                        </div><!--//media-body-->
                    </div><!--//media-->
                </div><!--//col-->
                <div class="col-12 col-lg-6 mb-5">
                    <div class="media shadow-sm p-4 rounded h-100">

                        <!---
                            /* Uncomment if you want to use a FontAwesome icon instead of an image */
                            <div class="theme-icon-holder mr-4"><i class="fas fa-code"></i></div>
                        -->
                        <img class="mr-3" src="<?php echo e(asset('assets/images/streamline-free/write-paper-ink.svg')); ?>" alt="">
                        <div class="media-body">
                            <h5 class="mt-0"><a href="docs-page-2">Documentação<i class="fas fa-long-arrow-alt-right ml-2"></i></a></h5>
                            Tem dúvidas técnicas? Confira nossa documentação. A ilustração usada aqui é de
                            <a class="theme-link" href="https://api.whatsapp.com/send?1=pt_BR&phone=258852502501&text=Sauda%C3%A7%C3%B5e%20Equipe%20Explicador,%20Gostaria%20de%20lecionar%20o%20curso%20de:__" target="_blank">Pacote de ilustrações grátis do Streamline
                            </a>
                        </div><!--//media-body-->
                    </div><!--//media-->
                </div><!--//col-->
            </div><!--//row-->
        </div><!--//container-->
    </section><!--//options-section-->
    <section class="contact-form-section mb-5">
        <div class="container">
            <form id="contact-form" class="contact-form p-5 col-lg-9 mx-lg-auto theme-bg-light shadow">
                <h3 class="text-center">  Faça uma pergunta</h3>
                <div class="form-row">

                    <div class="form-group col-md-6">
                        <label class="sr-only" for="cname">Name</label>
                        <input type="text" class="form-control" id="cname" name="name" placeholder="Name" minlength="2" required="" >
                    </div>
                    <div class="form-group col-md-6">
                        <label class="sr-only" for="cemail">Email</label>
                        <input type="email" class="form-control" id="cemail" name="email" placeholder="Email" required="" >
                    </div>

                    <div class="form-group col-12">
                        <label class="sr-only" for="cmessage">Your message</label>
                        <textarea class="form-control" id="cmessage" name="message" placeholder="Enter your message" rows="10" required=""></textarea>
                    </div>
                    <div class="form-group col-12">
                        <button type="submit" class="btn btn-block btn-primary py-2">Submit</button>
                    </div>
                </div><!--//form-row-->
            </form>
        </div><!--//container-->
    </section><!--//contact-form-section-->

</div><!--//page-content-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>