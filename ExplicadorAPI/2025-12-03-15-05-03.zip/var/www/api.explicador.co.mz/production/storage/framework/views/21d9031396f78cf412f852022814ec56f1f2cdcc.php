<?php $__env->startSection('main_content'); ?>

<div class="docs-wrapper">
    <div id="docs-sidebar" class="docs-sidebar">
        <div class="top-search-box d-lg-none p-3">
            <form class="search-form">
                <input type="text" placeholder="Search the docs..." name="search" class="form-control search-input">
                <button type="submit" class="btn search-btn" value="Search"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <nav id="docs-nav" class="docs-nav navbar">
            <ul class="section-items list-unstyled nav flex-column pb-3">
                <li class="nav-item section-title"><a class="nav-link scrollto active" href="#section-1"><span class="theme-icon-holder mr-2"><i class="fas fa-map-signs"></i></span>Introdução</a></li>
                <li class="nav-item"><a class="nav-link scrollto" href="#item-1-1">Por Que Rest?</a></li>
                <li class="nav-item"><a class="nav-link scrollto" href="#item-1-2">Quão Seguras São Suas Apis?</a></li>
                <li class="nav-item"><a class="nav-link scrollto" href="#item-1-4">Quais São As Operações Com Suporte?</a></li>

                <li class="nav-item section-title mt-3"><a class="nav-link scrollto" href="#section-2"><span class="theme-icon-holder mr-2"><i class="fas fa-arrow-down"></i></span>Intalação</a></li>
                <li class="nav-item"><a class="nav-link scrollto" href="#item-2-1">Credenciais da API</a></li>
                <li class="nav-item"><a class="nav-link scrollto" href="#item-2-2">Token de acesso</a></li>
                <li class="nav-item"><a class="nav-link scrollto" href="#item-2-3">Gerar token de acesso</a></li>
                <li class="nav-item section-title mt-3"><a class="nav-link scrollto" href="#section-3"><span class="theme-icon-holder mr-2"><i class="fas fa-box"></i></span>APIs</a></li>
                <li class="nav-item"><a class="nav-link scrollto" href="#item-3-1">Chamadas de API</a></li>
                <li class="nav-item"><a class="nav-link scrollto" href="#item-3-2">Algumas dicas</a></li>

                <li class="nav-item section-title mt-3"><a class="nav-link scrollto" href="#section-4"><span class="theme-icon-holder mr-2"><i class="fas fa-cogs"></i></span>Integrações</a></li>


                <li class="nav-item section-title mt-3"><a class="nav-link scrollto" href="#section-9"><span class="theme-icon-holder mr-2"><i class="fas fa-lightbulb"></i></span>FAQs</a></li>

            </ul>

        </nav><!--//docs-nav-->
    </div><!--//docs-sidebar-->
    <div class="docs-content">
        <div class="container">
            <article class="docs-article" id="section-1">
                <header class="docs-header">
                    <h1 class="docs-heading">Introdução <span class="docs-time">Last updated: 2019-06-01</span></h1>
                    <section class="docs-intro">
                        <p>
                            API significa Interface de Programação de Aplicativo. Uma API é um conjunto de funções e procedimentos que ajudam os usuários a acessar os recursos ou dados de um aplicativo, serviço ou sistema operacional diretamente de outro aplicativo. Vamos dar uma olhada em um exemplo simples para entendê-lo melhor.
                        </p>
                        <p>
                            Quando você está reservando um filme ou passagem aérea, geralmente verá uma opção Adicionar ao Google Agenda no site de reservas. Quando você clica neste botão, o site de reservas se comunica com o servidor do Google diretamente em segundo plano com uma solicitação para criar uma programação de eventos. O servidor do site de reservas processará a resposta e exibirá a mensagem de confirmação na tela. Em outras palavras, você está usando um recurso de um aplicativo sem acessar sua interface.
                        </p>
                        <p>
                            As APIs do ExplicadorAPI fornecem a opção para os usuários realizarem gerenciamento de usuários, gerenciamento de documentos e outras operações diretamente, sem acessar a interface da web doExplicadorAPI. Fornecemos Interface de Programação de Aplicativo de Transferência de Estado Representacional (API REST) ​​para atender a esse propósito.
                        </p>
                    </section><!--//docs-intro-->


                </header>
                <section class="docs-section" id="item-1-1">
                    <h2 class="section-heading">POR QUE REST?</h2>
                    <p>
                        A arquitetura da API REST aproveita os protocolos que já existem. Por exemplo, ele usa o protocolo HTTP para o APIS da web, o que significa que fornece grande flexibilidade para os desenvolvedores usarem as bibliotecas existentes enquanto constroem seus aplicativos personalizados. Foi originalmente desenvolvido pelo Dr. Roy Fielding em 2000 e adotado por desenvolvedores em todo o mundo por sua facilidade de uso e simplicidade.
                    </p>
                    <p>
                        Cada recurso é exposto como um URL, que pode ser obtido acessando o endpoint raiz da API.
                    </p>


                </section><!--//section-->

                <section class="docs-section" id="item-1-2">
                    <h2 class="section-heading">QUÃO SEGURAS SÃO SUAS APIS?</h2>
                    <p>
                        As APIs REST da ExplicadorAPI aproveitam o protocolo OAuth 2.0 padrão da indústria para autorização. Eles autorizam os aplicativos a interagir com eles sem realmente fornecer a senha. Em outras palavras, eles fornecem acesso delegado ao serviço e autorizam aplicativos de terceiros a acessar a conta do usuário com segurança.
                    </p>

                </section><!--//section-->

                <section class="docs-section" id="item-1-4">
                    <h2 class="section-heading">QUAIS SÃO AS OPERAÇÕES COM SUPORTE?</h2>
                    <p>
                        As APIs da ExplicadorAPI suportam uma lista crescente de operações mencionadas abaixo.
                    </p>
                </section><!--//section-->

            </article>

            <article class="docs-article" id="section-2">
                <header class="docs-header">
                    <h1 class="docs-heading">Instalação</h1>
                    <section class="docs-intro">
                        <p>Section intro goes here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque finibus condimentum nisl id vulputate. Praesent aliquet varius eros interdum suscipit. Donec eu purus sed nibh convallis bibendum quis vitae turpis. Duis vestibulum diam lorem, vitae dapibus nibh facilisis a. Fusce in malesuada odio.</p>
                    </section><!--//docs-intro-->
                </header>
                <section class="docs-section" id="item-2-1">
                    <h2 class="section-heading">Credenciais da API</h2>
                    <p>
                        Para poder criar as suas credenciais, você precisará de estar autenticado com uma <b>conta
                            com email confirmado</b> (a confirmação é feita quando você se regista nas nossas
                        plataformas).
                        A autenticação é feita com base numa das plataformas da Explicador, isso significa que se
                        você já tem conta, poderá entrar ou iniciar sessão no <b>e2Payments</b> usando a sua conta
                        de explicador.co.mz.
                    </p>
                    <p>Para autenticar-se:</p>
                    <ul>
                        <li>Opção 1 - Entrar ou criar a sua conta: <a href="https://account.explicador.co.mz" target="_blank">Gestor central das contas de
                                utilizadores</a></li>
                        <li>Opção 2 - Entrar ou criar a sua conta: <a href="/login">Entrar pelo e2Payments</a></li>
                    </ul>
                    <p>
                        Você precisa iniciar sessão na sua conta para ter acesso aos recursos de servidor. Depois de iniciar a sessão, você poderá criar as suas credenciais que terão o seguinte formato:

                    </p>
                    <h4 id="example-response-2">Exemplo 01 - credenciais da API:</h4>
                    <figure class="highlight">
                        <pre><code class="language-js" data-lang="js"><span class="p">{</span>
<span class="s2">"client_id"</span><span class="p">:</span> <span class="s2">"91fdae03-29a0-496c-9451-fb1e7dd2adffdf"</span><span class="p">,</span>
<span class="s2">"client_secret"</span><span class="p">:</span> <span class="s2">"T8sHdLfujgjZBp8aAf0Gsfu3kJgDzmNRUGEdN0sdfdsf"</span>
<span class="p">}</span></code></pre>
                    </figure>
                </section><!--//section-->

                <section class="docs-section" id="item-2-2">
                    <h2 class="section-heading">Token de acesso</h2>
                    <p>Um token de acesso é uma cadeia de caractéres opaca que identifica um utilizador, aplicativo ou Sistema. Ele pode ser usado pelo aplicativo para enviar requisições a API da e2Payments. Há diversos métodos que podem ser utilizados para obter tokens de acesso, mas nesta documentação, vamos explicar apenas um método principal.</p>

                    <p>O token inclui informações sobre quando o token expirará e qual aplicativo ou conta de utilizador gerou o token. Devido às verificações de privacidade e segurança, todas as chamadas ou requisições feitas a API de e2Payments precisam incluir um token de acesso.</p>

                    <p>Se deseja buscar qualquer recurso no servidor, precisará de solicitar um token de acesso para autenticação, todas as requisições que não possuem o token de acesso no Header, são bloqueadas, retornando-se o erro 401.</p>
                </section><!--//section-->

                <section class="docs-section" id="item-2-3">
                    <h2 class="section-heading">Armazenamento do Token de acesso</h2>
                    <p>Vivamus efficitur fringilla ullamcorper. Cras condimentum condimentum mauris, vitae facilisis leo. Aliquam sagittis purus nisi, at commodo augue convallis id. Sed interdum turpis quis felis bibendum imperdiet. Mauris pellentesque urna eu leo gravida iaculis. In fringilla odio in felis ultricies porttitor. Donec at purus libero. Vestibulum libero orci, commodo nec arcu sit amet, commodo sollicitudin est. Vestibulum ultricies malesuada tempor.</p>
                </section><!--//section-->
            </article><!--//docs-article-->


            <article class="docs-article" id="section-3">
                <header class="docs-header">
                    <h1 class="docs-heading">APIs</h1>
                    <section class="docs-intro">
                        <p>Section intro goes here. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque finibus condimentum nisl id vulputate. Praesent aliquet varius eros interdum suscipit. Donec eu purus sed nibh convallis bibendum quis vitae turpis. Duis vestibulum diam lorem, vitae dapibus nibh facilisis a. Fusce in malesuada odio.</p>
                    </section><!--//docs-intro-->
                </header>
                <section class="docs-section" id="item-3-1">
                    <h2 class="section-heading">Chamadas de API</h2>
                    <p>                    O token de acesso pode ser passado apenas no cabeçalho e não pode ser passado no parâmetro de solicitação.
                    </p>
                    <p>
                        O nome do cabeçalho deve ser O Authorizationvalor do cabeçalho deve serZoho-oauthtoken {access_token}

                    </p>
                </section><!--//section-->

                <section class="docs-section" id="item-3-2">
                    <h2 class="section-heading">Algumas dicas</h2>
                    <p>ExplicadorAPI usa verbos HTTP apropriados para cada ação.
                    </p>
                    <div class="table-responsive my-4">
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <th>Método</th>
                                <th>Descrição</th>
                            </tr>
                            <tr>
                                <td>GET</td>
                                <td>usado para recuperar recursos</td>
                            </tr>
                            <tr>
                                <td>STORE</td>
                                <td>usado para criar recursos e executar ações de recursos</td>
                            </tr>
                            <tr>
                                <td>PUT</td>
                                <td>usado para atualizar recursos</td>
                            </tr>
                            <tr>
                                <td>DELETE</td>
                                <td>usado para deletar recursos</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <ul>
                        <li>códigos de status na faixa 2xx significam sucesso</li>
                        <li>Intervalo 4xx significa que houve um erro nas informações fornecidas</li>
                        <li>aqueles na faixa 5xx indicam erros do lado do servidor.</li>
                    </ul>
                    <div class="table-responsive my-4">
                        <table class="table table-bordered">
                            <tbody>
                            <tr>
                                <th>Código de Status</th>
                                <th>Descrição</th>
                            </tr>
                            <tr>
                                <td>200</td>
                                <td>OK</td>
                            </tr>
                            <tr>
                                <td>400</td>
                                <td>pedido ruim</td>
                            </tr>
                            <tr>
                                <td>401</td>
                                <td>acesso não autorizado ou token de autenticação inválido</td>
                            </tr>
                            <tr>
                                <td>404</td>
                                <td>URL não encontrado</td>
                            </tr>
                            <tr>
                                <td>405</td>
                                <td>método não permitido ou método que você chamou não é compatível com a API chamada</td>
                            </tr>
                            <tr>
                                <td>500</td>
                                <td>erro interno</td>
                            </tr>
                            </tbody>
                        </table></div>
                </section><!--//section-->

                <section class="docs-section" id="item-3-3">
                    <h2 class="section-heading">Section Item 3.3</h2>
                    <p>Vivamus efficitur fringilla ullamcorper. Cras condimentum condimentum mauris, vitae facilisis leo. Aliquam sagittis purus nisi, at commodo augue convallis id. Sed interdum turpis quis felis bibendum imperdiet. Mauris pellentesque urna eu leo gravida iaculis. In fringilla odio in felis ultricies porttitor. Donec at purus libero. Vestibulum libero orci, commodo nec arcu sit amet, commodo sollicitudin est. Vestibulum ultricies malesuada tempor.</p>
                </section><!--//section-->
            </article><!--//docs-article-->

            <article class="docs-article" id="section-4">
                <header class="docs-header">
                    <h1 class="docs-heading">Integrações</h1>
                    <section class="docs-intro">
                        <p>Documentação ou explicação sobre como fazer a integração em diferentes projectos,...
                        </p>
                    </section><!--//docs-intro-->
                </header>

            </article><!--//docs-article-->


            <article class="docs-article" id="section-9">
                <header class="docs-header">
                    <h1 class="docs-heading">FAQs</h1>
                    <section class="docs-intro">
                        <p>Section intro goes here. You can list all your FAQs using the format below.</p>
                    </section><!--//docs-intro-->
                </header>
                <section class="docs-section" id="item-9-1">
                    <h2 class="section-heading">Section Item 9.1 <small>(FAQ Category One)</small></h2>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>What's sit amet quam eget lacinia?</h5>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.</p>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>How to ipsum dolor sit amet quam tortor?</h5>
                    <p>Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. </p>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>Can I  bibendum sodales?</h5>
                    <p>Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. </p>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>Where arcu sed urna gravida?</h5>
                    <p>Aenean et sodales nisi, vel efficitur sapien. Quisque molestie diam libero, et elementum diam mollis ac. In dignissim aliquam est eget ullamcorper. Sed id sodales tortor, eu finibus leo. Vivamus dapibus sollicitudin justo vel fermentum. Curabitur nec arcu sed urna gravida lobortis. Donec lectus est, imperdiet eu viverra viverra, ultricies nec urna. </p>
                </section><!--//section-->

                <section class="docs-section" id="item-9-2">
                    <h2 class="section-heading">Section Item 9.2 <small>(FAQ Category Two)</small></h2>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>What's sit amet quam eget lacinia?</h5>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.</p>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>How to ipsum dolor sit amet quam tortor?</h5>
                    <p>Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. </p>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>Can I  bibendum sodales?</h5>
                    <p>Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. </p>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>Where arcu sed urna gravida?</h5>
                    <p>Aenean et sodales nisi, vel efficitur sapien. Quisque molestie diam libero, et elementum diam mollis ac. In dignissim aliquam est eget ullamcorper. Sed id sodales tortor, eu finibus leo. Vivamus dapibus sollicitudin justo vel fermentum. Curabitur nec arcu sed urna gravida lobortis. Donec lectus est, imperdiet eu viverra viverra, ultricies nec urna. </p>
                </section><!--//section-->

                <section class="docs-section" id="item-9-3">
                    <h2 class="section-heading">Section Item 9.3 <small>(FAQ Category Three)</small></h2>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>How to dapibus sollicitudin justo vel fermentum?</h5>
                    <p>Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. </p>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>How long bibendum sodales?</h5>
                    <p>Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. </p>
                    <h5 class="pt-3"><i class="fas fa-question-circle mr-1"></i>Where dapibus sollicitudin?</h5>
                    <p>Aenean et sodales nisi, vel efficitur sapien. Quisque molestie diam libero, et elementum diam mollis ac. In dignissim aliquam est eget ullamcorper. Sed id sodales tortor, eu finibus leo. Vivamus dapibus sollicitudin justo vel fermentum. Curabitur nec arcu sed urna gravida lobortis. Donec lectus est, imperdiet eu viverra viverra, ultricies nec urna. </p>
                </section><!--//section-->
            </article><!--//docs-article-->

            <footer class="footer">
                <div class="container text-center py-5">
                    <small class="copyright">Template Copyright &copy; <a href="https://themes.3rdwavemedia.com/" target="_blank">3rd Wave Media</a></small>
                    <ul class="social-list list-unstyled pt-4 mb-0">
                        <li class="list-inline-item"><a href="#"><i class="fab fa-github fa-fw"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-twitter fa-fw"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-slack fa-fw"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-product-hunt fa-fw"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f fa-fw"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fab fa-instagram fa-fw"></i></a></li>
                    </ul><!--//social-list-->
                </div>
            </footer>
        </div>
    </div>
</div><!--//docs-wrapper-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>