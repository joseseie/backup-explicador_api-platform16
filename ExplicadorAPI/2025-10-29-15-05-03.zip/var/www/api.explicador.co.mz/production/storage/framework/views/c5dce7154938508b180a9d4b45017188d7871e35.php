<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('layouts.inc.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body>

<?php echo $__env->make('layouts.inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('main_content'); ?>

<?php echo $__env->make('layouts.inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.inc.file_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>

</html>

